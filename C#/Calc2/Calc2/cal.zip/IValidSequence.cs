﻿namespace CalculatorApp
{
    public interface IValidSequence
    {
        bool IsCorrectSequence(string a, int b);
    }
}
