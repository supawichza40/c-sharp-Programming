﻿public interface IValidateUserInput
{
    bool ValidInput(string val);
}

