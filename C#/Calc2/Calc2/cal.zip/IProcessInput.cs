﻿using System.Collections.Generic;

namespace CalculatorApp
{
    public interface IProcessInput
    {
        int CalculateInput(List<string> lis_input);
    }
}
